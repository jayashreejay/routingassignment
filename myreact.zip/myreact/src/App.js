import React from 'react'
import { BrowserRouter,Route,Switch } from 'react-router-dom';
import Home from './Home'
import Mounting from './Mounting'
import Updating from './Updating'
import Unmounting from './Unmounting'
import './Lifecycle.css'

function Apps() {
  return (
    <div className="App">
      <BrowserRouter>
      <Home />
      <Switch>
      <Route exact path="/mounting" component={Mounting}/>
      <Route exact path="/updating" component={Updating}/>
      <Route exact path="/unmounting" component={Unmounting} />
      </Switch>
      </BrowserRouter>
    </div>
  );
}

export default Apps;
