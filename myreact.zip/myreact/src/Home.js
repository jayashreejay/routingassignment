import React from 'react'
import {Link} from 'react-router-dom'
import Mounting from './Mounting'
import Updating from './Updating'
import Unmounting from './Unmounting'
import style from './Lifecycle.css'


const styles ={
      container:{
          float:'left',
          padding:'15px'
      }
}
export default class Home extends React.Component{
    constructor(props){
        super(props)
    }


    render (){
        return(
            <div>
              <div> <h1 style={{paddingLeft:'27rem',paddingTop:'3rem',paddingBottom:'1.5rem',backgroundColor:'blue'}}>React Component LifeCycle</h1> </div> 
                <div style={{...styles.container,paddingLeft:'30.5rem',color:'red'}}><Link to="/mounting"><h3>Mounting</h3></Link></div>
                <div style={styles.container}><Link to="/updating"><h3>Updating</h3></Link></div>
                <div style={{...styles.container,float:'none'}}><Link to="/unmounting"><h3>Unmounting</h3></Link></div>
            </div>
        )
    }
}