import React from 'react'
import style from './Lifecycle.css'



export default class Updating extends React.Component{
    constructor(props){
        super(props)
    }


    render (){
        return(
            <div>
               <h2> Updating</h2>
               <p> An update can be caused by changes to props or state. These methods are called in the following order when a component is being re-rendered:</p>

<li>static getDerivedStateFromProps()</li>
<li>shouldComponentUpdate()</li>
<li>render()</li>
<li>getSnapshotBeforeUpdate()</li>
<li>componentDidUpdate()</li>
<h3>getDerivedStateFromProps</h3>
<p>Also at updates the getDerivedStateFromProps method is called. This is the first method that is called when a component gets updated.<div>
    </div>This is still the natural place to set the state object based on the initial props.</p>
<h3>shouldComponentUpdate</h3>
<p>In the shouldComponentUpdate() method you can return a Boolean value that specifies whether React should continue with the rendering or not.
<div></div>
The default value is true.</p>
<h3>render()</h3>
<p>The render() method is of course called when a component gets updated, it has to re-render the HTML to the DOM, with the new changes.</p>
<h3>getSnapshotBeforeUpdate()</h3>
<p>In the getSnapshotBeforeUpdate() method you have access to the props and state before the update, meaning that even after the update, you can check what the values were before the update.
<div></div>
If the getSnapshotBeforeUpdate() method is present, you should also include the componentDidUpdate() method, otherwise you will get an error.</p>
<h3>componentDidUpdate()</h3>
<p>The componentDidUpdate method is called after the component is updated in the DOM.    </p>
           
         </div>
        )
    }
}